@extends('layouts.master')
@section('title','Reset Password')
@section('content')


@endsection