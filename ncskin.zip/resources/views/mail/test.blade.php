<!DOCTYPE html>
<html>
<head>
	<title>Send Email</title>
</head>
<body>
	<h2>Hi Welcome to Test Mail :</h2>
</body>
</html>