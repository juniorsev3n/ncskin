<?php $__env->startSection('title', 'Shop'); ?>

<?php $__env->startSection('content'); ?>

<section id="products-grid-sidebar" class="section-products-grid">
    <div class="container">
        <div class="col-xs-12 col-md-3">
            <div class="sidebar">
                <div class="accordion-widget category-accordions">
                    
                    <h2>Categories</h2>
                    
                    <?php if(count($categories) > 0): ?>
                    <div class="accordion" >
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-group">
                            <div class="accordion-heading">
                            <?php if($category->children > 0): ?>
                                    <a class="accordion-toggle" data-toggle="collapse" href="#collapse<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a>
                            </div>
                            <div id="collapse<?php echo e($category->id); ?>" class="accordion-body collapse in">
                                <div class="accordion-inner">
                                    <a href="/category/<?php echo e($category->slug); ?>">All <?php echo e($category->name); ?></a>
                                    <?php $__currentLoopData = $category->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul>
                                            <li>
                                                <a href="/category/<?php echo e($category->slug); ?>"><?php echo e($category->name); ?></a>
                                            </li>
                                    </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <?php else: ?>
                                <a class="accordion-toggle direct-link" href="/category/<?php echo e($category->slug); ?>"><?php echo e($category->name); ?></a>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>                    
                </div>
            </div>
        </div>
        <div class="col-xs-12 col-md-9">
            
            <?php if(count($categories) < 1): ?>
                <h2>Category not found</h2>
                <p>We are sorry, the requested category was not found.</p>
            <?php else: ?>
            <div class="banner">
                <img alt="" class="lazy" src="images/homepage-3-banner.jpg" />
            </div>
            <div class="row">
                <div class="col-xs-6">
                </div>
                <div class="col-xs-6">
                    <div class="grid-list-buttons">
                        <ul class="list-inline">
                            <li class="active"><a data-toggle="tab" href="#grid-view"><i class="fa fa-th-large"></i> Grid</a></li>
                            <li ><a data-toggle="tab" href="#list-view"><i class="fa fa-th-list"></i> List</a></li>
                        </ul>
                    </div>
                </div>
            </div>            
            

                <div class="product-grid no-move-down tab-content">
    
                    <!-- grid view starts here -->
                    <div id="grid-view" class="tab-pane active">
                        
                       <div class="row">
                            <?php if(count($products) > 0): ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-4 col-xs-12 col-sm-6 product-holder">
                                        <form class="custom" onsubmit="return false">
                                        <div class="product-item text-center">
                                            <?php  
                                            $images = json_decode($product->images, TRUE);
                                             ?>
                                            <?php if(count($images) > 1): ?>
                                                <a href="#next" class="mini-next"></a>
                                                <a href="#prev" class="mini-prev"></a>
                                                <div class="image ">
                                                    <div class="product-mini-gallery">
                                                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a style="display:inline-block;" href="/product/<?php echo e($product->slug); ?>">
                                                            <img alt="<?php echo e($product->name); ?>" src="<?php echo e($value); ?>" width="212" height="281" />
                                                        </a>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <a href="/product/<?php echo e($product->slug); ?>">
                                                    <img class="product-img" src="<?php echo e($images); ?>" alt="<?php echo e($product->name); ?>" />
                                                </a>
                                            <?php endif; ?>
                                            <hr>
                                            <div class="title uppercase bold">
                                                <a href="/product/<?php echo e($product->slug); ?>"><?php echo e($product->name); ?></a>
                                            </div>
                                            <div class="price">
                                                <?php if($product->is_discount == TRUE): ?>
                                                        <span class="previous-price"><?php echo e($product->pricet - ($product->discount * $product->price)); ?></span>
                                                <?php endif; ?>
                                                <span><?php echo e($product->price); ?></span>
                                            </div>
                                            <div class="buttons-holder">
                                                <div class="add-cart-holder">
                                                    <input type="hidden" name="productId" value="<?php echo e($product->id); ?>"/>
                                                    <a class="md-button" href="#" data-ajax-handler="shop:onAddToCart" data-ajax-update="#mini-cart=shop-minicart, #product-page=shop-product">Add to Cart</a>
                                                </div>
                                            </div>
                                        </div>
                                        </form>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="col-xs-12">
                                    <h2 class="empty">There are no products in this category.</h2>
                                </div>
                            <?php endif; ?>
                        </div>
    
                    </div>
                    <!-- List View starts here-->
                    <div id="list-view" class="tab-pane">
                    
                       <div class="products-list-holder">
                            <?php if(count($products) > 1): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <form class="custom" onsubmit="return false">
                            <div class="product-list-item">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-4">
                                        <div class="image-holder">
                                        <?php  $images = json_decode($product->images)
                                         ?>
                                            <a href="/product/<?php echo e($product->slug); ?>"><img class="product-img" alt="<?php echo e($product->name); ?>" src="<?php echo e($images[0]); ?>" /></a> 
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-8">
                                        <div class="item-details-holder">
                                            <h2 class="title" ><a href="/product/<?php echo e($product->slug); ?>"><?php echo e($product->name); ?></a></h2>
                                            <div class="excerpt">
                                                <?php echo e($product->description); ?>

                                            </div>
                                            
                                            <div class="price">
                                                <?php if($product->is_discount == TRUE): ?>
                                                        <span class="previous-price"><?php echo e($product->pricet - ($product->discount * $product->price)); ?></span>
                                                <?php endif; ?>
                                                <span><?php echo e($product->price); ?></span>
                                            </div>
                                            <div class="buttons-holder">
                                                <div class="add-cart-holder">
                                                    <input type="hidden" name="productId" value="<?php echo e($product->id); ?>"/>
                                                    <a class="md-button" href="#" data-ajax-handler="shop:onAddToCart" data-ajax-update="#mini-cart=shop-minicart, #product-page=shop-product">Add to Cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <h2 class="empty">There are no products in this category.</h2>
                            <?php endif; ?>
                        </div>
                    
                    </div>
                        
                </div>
                
                <!--<div class="paging-holder">-->
                    <?php echo e($products->links('vendor.pagination.default')); ?>

                <!--</div>
                
                    
            <?php endif; ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>