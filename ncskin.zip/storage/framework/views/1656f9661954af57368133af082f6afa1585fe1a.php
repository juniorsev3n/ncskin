<?php $__env->startSection('title', 'Login | Register'); ?>
<?php $__env->startSection('content'); ?>

<section class="section-signin-page">
    <div class="container">
        <div class="sign-in-holder">
            <div class="row">
                <div class="col-xs-12 col-sm-6">
                    <?php if(!empty(session('error'))): ?>
                        <div class="alert-danger"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>
                    <form action="<?php echo e(url('login')); ?>" method="post">
                        <h3>Login</h3>
                        <input name="email" class="md-input col-xs-12" placeholder="e-mail" value="<?php echo e(old('email')); ?>">
                        <?php if($errors->first('email')): ?>
                        <span class="alert-danger"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>
                        <input type="password" name="password" class="md-input col-xs-12" placeholder="password">
                        <?php if($errors->first('password')): ?>
                        <span class="alert-danger"><?php echo e($errors->first('password')); ?></span><br>
                        <?php endif; ?>
                        <a class="forget-link" href="<?php echo e(url('/password-reset')); ?>">forgot your password?</a>
                        <button class="md-button narrow " type="submit">sign in</button>
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-xs-12" align="center"><a href="<?php echo e(url('/login/facebook')); ?>"><img src="<?php echo e(url('images/icon/facebook.png')); ?>" width="250"></a></div>
                            <div class="col-xs-12" align="center"><a href="<?php echo e(url('/login/google')); ?>"><img src="<?php echo e(url('images/icon/google.png')); ?>" width="250"></a></div>
                        </div>
                    </form>
                </div>
                <div class="col-xs-12 col-sm-6">
                    <form action="<?php echo e(url('register')); ?>" method="post">
                        <h3>Register</h3>

                        <input name="firstname" type="text" class="md-input col-xs-12" placeholder="First Name *" />

                        <input name="lastname" type="text" class="md-input col-xs-12"  placeholder="Last Name *"/>

                        <input id="email" type="text" name="email" class="md-input col-xs-12"  placeholder="Email *"/>

                        <input name="password" type="password" class="md-input col-xs-12"  placeholder="Password *"/>

                        <input name="password_confirmation" type="password" class="md-input col-xs-12"  placeholder="Confirm Password *" style="margin-bottom: 15px"/><br>

                        <input class="md-check" name="subscribe" type="checkbox" id="accepts_marketing" checked/> Recieve promotional emails
                        <button class="md-button narrow">submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>