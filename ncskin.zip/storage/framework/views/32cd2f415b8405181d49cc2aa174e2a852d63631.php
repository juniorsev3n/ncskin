<?php $__env->startSection('title','Cart'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-12 col-lg-9">
    <div class="items-holder">
        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="cart-item row">
		    <div class="col-sm-2 col-lg-1">
		        <div class="image">
		            <img width="60" height="60" alt="" src="" />
		        </div>
		    </div>
		    <div class="col-sm-4 col-lg-6">
		        <div class="brand">
		        </div>
		        <div class="title">
		            <a href="/product/"></a>
		            <ul class="options">
		        <?php if(isset($description)): ?>
		          <li><?php echo e($description); ?></li>
		        <?php endif; ?>
		      </ul>
		        </div>
		        <div class="bulk-pricing">
		            <?php if(isset($discount)): ?>
		                <p class="bold">Bulk Pricing</p>
		                <div class="widget shopping-cart-summary">
		                    <table class="volume-pricing-table">
		                        <thead><tr><td>Qty</td><td>Price</td></tr></thead>  
		                        <tr>
		                            <td>
		                                 if loop.last  priceTier.quantity+
		                                 else   priceTier.quantity - item.product.priceTiers[loop.index].quantity - 1  endif 
		                            </td>
		                            <td><?php echo e($content->price); ?></td>
		                        </tr>
		                    </table>
		                </div>
		            <?php endif; ?>
		        </div>
		    </div>
		    <div class="col-sm-6 col-lg-5 details">
		        <div class="unit-price">
		             <?php echo e($content->price); ?> 
		        </div>
		        <div class="quantity">
		                <input type="text" name="item_quantity" class="md-input quantity" value="<?php echo e($content->qty); ?>"> 
		        </div>
		        <div class="total-price">
		             <?php echo e($content->qty); ?> 
		        </div>
		            <a class="close-btn" href="#close"
		            data-ajax-handler="shop:cart"
		            data-ajax-update="#cart-content=shop-cart-content, #mini-cart=shop-minicart"
		            data-ajax-extra-fields="delete_item=' '"></a> 
		    </div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>            
</div>
<div id="cart-totals">
<div class="col-md-12 col-lg-3">
    <div class="right-sidebar">
     <?php if(count($cart) > 0): ?> 
        <div class="widget shopping-cart-summary">
            <h4 class="md-bordered-title">shopping cart summary</h4>
            <form>

                 <?php if(isset($total)): ?> 
                    <fieldset>
                        <label class="col-xs-6">discount</label>
                        <span class="col-xs-6 value"> totals.discountTotal</span>
                    </fieldset>
                 <?php endif; ?> 

                <fieldset>
                    <label class="col-xs-6">cart subtotal</label>
                    <span class="col-xs-6 value"> totals.subtotal</span>
                </fieldset>

                 <?php if(\Request::get('shop')): ?> 
                    <fieldset>
                        <label class="col-xs-6">sales tax</label>
                        <span class="col-xs-6 value">totals.totalTax</span>
                    </fieldset>
                    <fieldset>
                        <label class="col-xs-6">shipping</label>
                        <span class="col-xs-6 value"> totals.totalShippingQuote</span>
                    </fieldset>
                    <hr>
                    <fieldset class="total">
                        <label class="col-xs-6">order total</label>
                        <span class="col-xs-6 value"> totals.total|currency </span>
                    </fieldset>
                 <?php else: ?>  

                    <input class="md-input col-xs-12" placeholder="coupon code" value=" coupon_code " name="coupon" id="coupon"/>

                    <a class="md-button black" href="#" data-ajax-handler="shop:cart" data-ajax-update="#cart-content=shop-cart-content, #mini-cart=shop-minicart">Update cart</a>

                     <?php if(\Auth::check()): ?> 
                        <a class="md-button large col-xs-12" href=" url('/checkout') ">Checkout</a>
                            <a href="<?php echo e(url('shop')); ?>">continue shopping</a>
                     <?php else: ?> 
                        <a class="md-button large col-xs-12" href=" url('/checkout-start') ">Checkout</a>
                            <a href="<?php echo e(url('shop')); ?>">continue shopping</a>
                     <?php endif; ?> 

                 <?php endif; ?>
            </form>
        </div>

     <?php else: ?> 
        <h4 class="md-bordered-title">Your cart is empty!</h4>
        <a class="md-button col-xs-12 cart-empty-button" href="<?php echo e(url('shop')); ?> ">Continue shopping <span class="fa fa-arrow-circle-right"></span></a>
     <?php endif; ?> 
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>